package com.evrenler.mod;

import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.WrongUsageException;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.TextComponentString;

public class CommandEvren extends CommandBase {
    @Override
    public String getName() { return "evren"; }

    @Override
    public String getUsage(ICommandSender sender) { return "/evren <1-30>  (0 = normal dünya, liste = isimler)"; }

    @Override
    public int getRequiredPermissionLevel() { return 0; }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        if (args.length < 1) throw new WrongUsageException(getUsage(sender));
        if (args[0].equalsIgnoreCase("liste")) {
            for (int i = 0; i < Universes.COUNT; i++)
                sender.sendMessage(new TextComponentString((i + 1) + " - " + Universes.ALL[i].name));
            return;
        }
        int n = parseInt(args[0], 0, Universes.COUNT);
        EntityPlayerMP p = getCommandSenderAsPlayer(sender);
        int dim = n == 0 ? 0 : Universes.BASE_DIM + n - 1;
        p.changeDimension(dim, new UniverseTeleporter());
        sender.sendMessage(new TextComponentString(n == 0 ? "Normal dünyaya dönüldü." : "Evren " + n + ": " + Universes.ALL[n - 1].name));
    }
}
