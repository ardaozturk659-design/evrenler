package com.evrenler.mod;

import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class CommonEvents {
    /** Evrenlerde hava açık olsa bile ara sıra oyuncunun yakınına yıldırım düşer. */
    @SubscribeEvent
    public void onWorldTick(TickEvent.WorldTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.world.isRemote) return;
        World w = e.world;
        if (Universes.indexOfDim(w.provider.getDimension()) < 0 || w.playerEntities.isEmpty()) return;
        if (w.rand.nextInt(300) != 0) return;
        EntityPlayer p = w.playerEntities.get(w.rand.nextInt(w.playerEntities.size()));
        int x = (int) p.posX + w.rand.nextInt(81) - 40;
        int z = (int) p.posZ + w.rand.nextInt(81) - 40;
        BlockPos probe = new BlockPos(x, 0, z);
        if (!w.isBlockLoaded(probe)) return;
        BlockPos top = w.getHeight(probe);
        w.addWeatherEffect(new EntityLightningBolt(w, top.getX(), top.getY(), top.getZ(), true));
    }
}
