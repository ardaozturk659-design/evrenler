package com.evrenler.mod;

import java.util.Random;

import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/** Yıldırımı seçilen renkte çizer. */
@SideOnly(Side.CLIENT)
public class RenderUniverseLightning extends Render<EntityLightningBolt> {

    public RenderUniverseLightning(RenderManager rm) { super(rm); }

    @Override
    public void doRender(EntityLightningBolt e, double x, double y, double z, float yaw, float pt) {
        int idx = Universes.indexOfDim(e.world.provider.getDimension());
        int col = idx >= 0 ? ColorConfig.get(idx, ColorConfig.LIGHTNING) : 0xE6E6F2;
        float r = ((col >> 16) & 255) / 255f, g = ((col >> 8) & 255) / 255f, b = (col & 255) / 255f;

        GlStateManager.disableTexture2D();
        GlStateManager.disableLighting();
        GlStateManager.disableCull();
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
        GlStateManager.depthMask(false);

        Random rand = new Random(e.boltVertex);
        int seg = 16;
        double[] ox = new double[seg + 1], oz = new double[seg + 1];
        for (int i = 1; i <= seg; i++) {
            ox[i] = ox[i - 1] + (rand.nextInt(9) - 4);
            oz[i] = oz[i - 1] + (rand.nextInt(9) - 4);
        }

        Tessellator t = Tessellator.getInstance();
        BufferBuilder bb = t.getBuffer();
        float[] widths = {0.12f, 0.3f, 0.6f};
        float[] alphas = {0.9f, 0.35f, 0.15f};
        for (int k = 0; k < 3; k++) {
            double w = widths[k];
            bb.begin(7, DefaultVertexFormats.POSITION_COLOR);
            for (int i = 0; i < seg; i++) {
                double y0 = y + 16.0 * i, y1 = y + 16.0 * (i + 1);
                double xa = x + ox[i], za = z + oz[i], xb = x + ox[i + 1], zb = z + oz[i + 1];
                bb.pos(xa - w, y0, za).color(r, g, b, alphas[k]).endVertex();
                bb.pos(xa + w, y0, za).color(r, g, b, alphas[k]).endVertex();
                bb.pos(xb + w, y1, zb).color(r, g, b, alphas[k]).endVertex();
                bb.pos(xb - w, y1, zb).color(r, g, b, alphas[k]).endVertex();
                bb.pos(xa, y0, za - w).color(r, g, b, alphas[k]).endVertex();
                bb.pos(xa, y0, za + w).color(r, g, b, alphas[k]).endVertex();
                bb.pos(xb, y1, zb + w).color(r, g, b, alphas[k]).endVertex();
                bb.pos(xb, y1, zb - w).color(r, g, b, alphas[k]).endVertex();
            }
            t.draw();
        }

        GlStateManager.depthMask(true);
        GlStateManager.disableBlend();
        GlStateManager.enableCull();
        GlStateManager.enableLighting();
        GlStateManager.enableTexture2D();
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityLightningBolt entity) { return null; }
}
