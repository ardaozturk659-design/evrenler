package com.evrenler.mod;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.common.util.ITeleporter;

public class UniverseTeleporter implements ITeleporter {
    @Override
    public void placeEntity(World world, Entity entity, float yaw) {
        int idx = Universes.indexOfDim(world.provider.getDimension());
        BlockPos target;
        float newYaw = yaw;
        if (idx < 0) {
            BlockPos s = world.getSpawnPoint();
            target = world.getTopSolidOrLiquidBlock(s);
        } else {
            int z = Universes.ALL[idx].castle ? -120 : 0; // şatonun önünde doğ
            target = world.getTopSolidOrLiquidBlock(new BlockPos(0, 0, z));
            newYaw = 0f; // güneye (şatoya) bak
        }
        entity.motionX = entity.motionY = entity.motionZ = 0;
        entity.fallDistance = 0;
        entity.setLocationAndAngles(target.getX() + 0.5, target.getY() + 1, target.getZ() + 0.5, newYaw, 0f);
    }
}
