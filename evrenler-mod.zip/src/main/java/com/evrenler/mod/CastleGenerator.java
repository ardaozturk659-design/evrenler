package com.evrenler.mod;

import net.minecraft.block.BlockColored;
import net.minecraft.block.BlockStainedGlass;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.item.EnumDyeColor;

/**
 * Karanlık Evren'in dev şatosu. Merkez (0,0), zemin y=64.
 * Her blok için "burada ne var?" diye hesaplanır; böylece chunk sınırı sorunu olmaz.
 */
public class CastleGenerator {
    public static final int MAX_Y = 190;
    public static final int RADIUS = 80;

    private static final IBlockState WALL = Blocks.CONCRETE.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.BLACK);
    private static final IBlockState ROOF = Blocks.STAINED_HARDENED_CLAY.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.BLACK);
    private static final IBlockState TRIM = Blocks.OBSIDIAN.getDefaultState();
    private static final IBlockState FLOOR = Blocks.COAL_BLOCK.getDefaultState();
    private static final IBlockState GLASS = Blocks.STAINED_GLASS.getDefaultState().withProperty(BlockStainedGlass.COLOR, EnumDyeColor.RED);

    // {merkezX, merkezZ, yarıçap, tepeY, çatıYüksekliği, tabanY}
    private static final int[][] TOWERS = {
            {64, 64, 9, 95, 26, 65}, {-64, 64, 9, 95, 26, 65}, {64, -64, 9, 95, 26, 65}, {-64, -64, 9, 95, 26, 65},
            {64, 0, 7, 80, 20, 65}, {-64, 0, 7, 80, 20, 65}, {0, 64, 7, 80, 20, 65},
            {-11, -64, 6, 90, 22, 65}, {11, -64, 6, 90, 22, 65},
            {28, 28, 6, 118, 24, 65}, {-28, 28, 6, 118, 24, 65}, {28, -28, 6, 118, 24, 65}, {-28, -28, 6, 118, 24, 65}
    };

    public static boolean overlapsChunk(int chunkX, int chunkZ) {
        int minX = chunkX * 16, minZ = chunkZ * 16;
        return minX + 15 >= -RADIUS && minX <= RADIUS && minZ + 15 >= -RADIUS && minZ <= RADIUS;
    }

    /** null = şatoya ait blok yok (hava veya arazi). */
    public static IBlockState get(int x, int y, int z) {
        if (Math.abs(x) > RADIUS || Math.abs(z) > RADIUS || y < 64 || y > MAX_Y) return null;

        if (y == 64) {
            return (Math.abs(x) <= 28 && Math.abs(z) <= 28) ? FLOOR : null;
        }

        // Kuleler (içleri oyuk, alanlarına girince kule kuralı geçerli)
        for (int[] t : TOWERS) {
            int dx = x - t[0], dz = z - t[1];
            int r = t[2];
            if (Math.abs(dx) > r + 2 || Math.abs(dz) > r + 2) continue;
            if (Math.sqrt(dx * dx + dz * dz) <= r + 1.5) {
                return tower(dx, dz, y, r, t[3], t[4], t[5]);
            }
        }

        // Orta sivri kule (ana yapının çatısından yukarı)
        if (y > 100 && Math.sqrt(x * x + z * z) <= 10.5) {
            return tower(x, z, y, 9, 135, 40, 100);
        }

        int m = Math.max(Math.abs(x), Math.abs(z));

        // Ana kale (keep)
        if (m <= 28) {
            if (y <= 99) {
                if (m >= 25) {
                    if (z <= -25 && Math.abs(x) <= 4 && y <= 77) return null; // ana kapı
                    int rel = y - 64;
                    if (rel % 18 == 0) return TRIM;
                    if ((rel >= 6 && rel <= 11) || (rel >= 24 && rel <= 29)) {
                        int c = (Math.abs(z) >= 25 && Math.abs(z) >= Math.abs(x)) ? x : z;
                        int mod = Math.floorMod(c, 6);
                        if (mod == 2 || mod == 3) return GLASS;
                    }
                    return WALL;
                }
                return (y == 82) ? FLOOR : null;
            }
            if (y == 100) return WALL;
            if (y == 101 && m >= 27 && ((x + z) & 1) == 0) return TRIM;
            return null;
        }

        // Dış sur
        if (m >= 60 && m <= 64) {
            if (z <= -60 && Math.abs(x) <= 5 && y <= 80) return null; // sur kapısı
            if (y <= 86) return ((y - 64) % 12 == 0) ? TRIM : WALL;
            if (y == 87) return TRIM;
            if (y <= 89 && (m == 64 || m == 60) && ((x + z) & 1) == 0) return TRIM;
        }
        return null;
    }

    private static IBlockState tower(int dx, int dz, int y, int r, int topY, int roofH, int baseY) {
        double d = Math.sqrt(dx * dx + dz * dz);
        int rel = y - baseY;
        if (y <= topY) {
            if (d <= r && d > r - 2.5) {
                if (rel % 16 == 0) return TRIM;
                int k = rel % 16;
                if (k >= 9 && k <= 11 && d > r - 1.5 && (Math.abs(dx) <= 1 || Math.abs(dz) <= 1)) return GLASS;
                return WALL;
            }
            if (d <= r - 2.5 && (y == topY || rel % 16 == 15)) return FLOOR;
            return null;
        }
        int t = y - topY;
        if (t <= roofH) {
            double rr = (r + 1.5) * (1.0 - (double) (t - 1) / roofH);
            if (d <= rr && d > rr - 1.8) return ROOF;
        }
        return null;
    }
}
