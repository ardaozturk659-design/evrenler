package com.evrenler.mod;

import java.io.IOException;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/** B tuşu menüsü: Gökyüzünün Rengi / Yıldırım Rengi / Çimenin Rengi */
@SideOnly(Side.CLIENT)
public class GuiColorMenu extends GuiScreen {
    private int uni;

    @Override
    public void initGui() {
        uni = ClientEvents.current();
        int cx = width / 2, cy = height / 2;
        buttonList.clear();
        buttonList.add(new GuiButton(0, cx - 100, cy - 40, 200, 20, "Gökyüzünün Rengi"));
        buttonList.add(new GuiButton(1, cx - 100, cy - 14, 200, 20, "Yıldırım Rengi"));
        buttonList.add(new GuiButton(2, cx - 100, cy + 12, 200, 20, "Çimenin Rengi"));
        buttonList.add(new GuiButton(3, cx - 100, cy + 44, 200, 20, "Kapat"));
        if (uni < 0) for (int i = 0; i < 3; i++) buttonList.get(i).enabled = false;
    }

    @Override
    protected void actionPerformed(GuiButton b) throws IOException {
        if (b.id < 3) mc.displayGuiScreen(new GuiColorPicker(this, uni, b.id));
        else mc.displayGuiScreen(null);
    }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        drawDefaultBackground();
        drawCenteredString(fontRenderer, "Evren Renk Ayarları", width / 2, height / 2 - 78, 0xFFFFFF);
        String sub = uni >= 0 ? "Evren " + (uni + 1) + ": " + Universes.ALL[uni].name
                : "Bir evrende değilsin. Sohbete /evren 1 yaz.";
        drawCenteredString(fontRenderer, sub, width / 2, height / 2 - 62, 0xAAAAAA);
        super.drawScreen(mx, my, pt);
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
