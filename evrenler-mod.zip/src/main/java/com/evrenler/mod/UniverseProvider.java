package com.evrenler.mod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.world.DimensionType;
import net.minecraft.world.WorldProvider;
import net.minecraft.world.biome.BiomeProviderSingle;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraftforge.client.IRenderHandler;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class UniverseProvider extends WorldProvider {

    private int idx() {
        int i = Universes.indexOfDim(getDimension());
        return i < 0 ? 0 : i;
    }

    @Override
    protected void init() {
        this.hasSkyLight = true;
        this.biomeProvider = new BiomeProviderSingle(ModBiomes.BIOMES[idx()]);
    }

    @Override
    public IChunkGenerator createChunkGenerator() {
        return new UniverseChunkGenerator(world, idx());
    }

    @Override
    public DimensionType getDimensionType() {
        return ModDimensions.TYPES[idx()];
    }

    @Override
    public float calculateCelestialAngle(long worldTime, float partialTicks) {
        return Universes.ALL[idx()].celestial;
    }

    @Override
    public boolean isSurfaceWorld() { return true; }

    @Override
    public int getAverageGroundLevel() { return 64; }

    @Override
    @SideOnly(Side.CLIENT)
    public IRenderHandler getSkyRenderer() { return SkyRenderer.INSTANCE; }

    @Override
    @SideOnly(Side.CLIENT)
    public IRenderHandler getCloudRenderer() {
        return new IRenderHandler() {
            @Override
            public void render(float partialTicks, WorldClient world, Minecraft mc) { /* bulut yok */ }
        };
    }
}
