package com.evrenler.mod;

import net.minecraft.block.Block;
import net.minecraft.block.BlockColored;
import net.minecraft.block.BlockDirt;
import net.minecraft.block.BlockSand;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.item.EnumDyeColor;

/** 30 evrenin tüm verisi burada. Dimension ID = 100 + (evren no - 1). */
public class Universes {
    public static final int COUNT = 30;
    public static final int BASE_DIM = 100;
    public static final int NONE = 0, SPIKE = 1, TREE = 2, PILLAR = 3;
    public static final UniverseData[] ALL = new UniverseData[COUNT];

    public static class UniverseData {
        public String name;
        public IBlockState top, fill, stone, liquid, decor;
        public int sea, base, amp, sky, fog, grass, lightning, decorKind, decorCount;
        public float density, celestial;
        public boolean castle;
    }

    private static IBlockState b(Block x) { return x.getDefaultState(); }
    private static IBlockState concrete(EnumDyeColor c) { return Blocks.CONCRETE.getDefaultState().withProperty(BlockColored.COLOR, c); }
    private static IBlockState black() { return concrete(EnumDyeColor.BLACK); }
    private static IBlockState redSand() { return Blocks.SAND.getDefaultState().withProperty(BlockSand.VARIANT, BlockSand.EnumType.RED_SAND); }
    private static IBlockState podzol() { return Blocks.DIRT.getDefaultState().withProperty(BlockDirt.VARIANT, BlockDirt.DirtType.PODZOL); }

    private static UniverseData u(String name, IBlockState top, IBlockState fill, IBlockState stone, IBlockState liquid,
                                  int sea, int base, int amp, int sky, int fog, int grass, int lightning,
                                  float density, float celestial, int kind, IBlockState decor, int count) {
        UniverseData d = new UniverseData();
        d.name = name; d.top = top; d.fill = fill; d.stone = stone; d.liquid = liquid;
        d.sea = sea; d.base = base; d.amp = amp; d.sky = sky; d.fog = fog; d.grass = grass; d.lightning = lightning;
        d.density = density; d.celestial = celestial; d.decorKind = kind; d.decor = decor; d.decorCount = count;
        return d;
    }

    static {
        // 1 - SENİN İSTEDİĞİN: simsiyah evren, siyah çimen, siyah gökyüzü, gri sis, dev şato
        ALL[0] = u("Karanlık Evren", b(Blocks.GRASS), b(Blocks.DIRT), b(Blocks.STONE), null, 0, 64, 6,
                0x000000, 0x6E6E6E, 0x000000, 0xFFFFFF, 0.014f, 0.0f, TREE, black(), 3);
        ALL[0].castle = true;

        ALL[1] = u("Kan Çölü", redSand(), b(Blocks.RED_SANDSTONE), b(Blocks.RED_SANDSTONE), b(Blocks.LAVA), 55, 62, 8,
                0x5A0000, 0x3A0000, 0x7A0A0A, 0xFF0000, 0.02f, 0f, SPIKE, b(Blocks.NETHER_WART_BLOCK), 4);
        ALL[2] = u("Çürük Orman", podzol(), b(Blocks.DIRT), b(Blocks.STONE), null, 0, 66, 10,
                0x1A2A10, 0x2B3A1E, 0x4B5A1A, 0xAAFF55, 0.02f, 0f, TREE, b(Blocks.LOG), 7);
        ALL[3] = u("Hayalet Okyanus", b(Blocks.SAND), b(Blocks.SAND), b(Blocks.SANDSTONE), b(Blocks.WATER), 70, 52, 12,
                0x8FA8B8, 0xB0C4CE, 0x9FD0C0, 0xCCFFFF, 0.03f, 0f, PILLAR, b(Blocks.QUARTZ_BLOCK), 2);
        ALL[4] = u("Mor Bataklık", b(Blocks.MYCELIUM), b(Blocks.DIRT), b(Blocks.STONE), b(Blocks.WATER), 63, 62, 5,
                0x2A0A3A, 0x3D1A4F, 0x7A2FA8, 0xB84DFF, 0.025f, 0f, TREE, b(Blocks.LOG), 5);
        ALL[5] = u("Kemik Ovası", b(Blocks.SAND), b(Blocks.SANDSTONE), b(Blocks.SANDSTONE), null, 0, 64, 8,
                0xB8B090, 0xD0CBB0, 0xCCC8A0, 0xFFFFFF, 0.012f, 0f, SPIKE, b(Blocks.BONE_BLOCK), 6);
        ALL[6] = u("Kızıl Ay Dünyası", b(Blocks.GRASS), b(Blocks.DIRT), b(Blocks.STONE), null, 0, 66, 12,
                0x300000, 0x4A0000, 0x8B1A1A, 0xFF3030, 0.018f, 0.5f, PILLAR, b(Blocks.RED_NETHER_BRICK), 3);
        ALL[7] = u("Cam Mezarlık", b(Blocks.GRAVEL), b(Blocks.GRAVEL), b(Blocks.STONE), null, 0, 64, 6,
                0x202838, 0x3A4252, 0x667788, 0x88CCFF, 0.02f, 0f, PILLAR, b(Blocks.GLASS), 5);
        ALL[8] = u("Ateş Gölü", b(Blocks.NETHERRACK), b(Blocks.NETHERRACK), b(Blocks.NETHERRACK), b(Blocks.LAVA), 66, 58, 14,
                0x401000, 0x802000, 0xFF6A00, 0xFFAA00, 0.02f, 0f, SPIKE, b(Blocks.MAGMA), 4);
        ALL[9] = u("Kar Kabusu", b(Blocks.SNOW), b(Blocks.DIRT), b(Blocks.STONE), null, 0, 66, 10,
                0x9AB0C8, 0xC8D8E8, 0xE0F0FF, 0xFFFFFF, 0.035f, 0f, SPIKE, b(Blocks.PACKED_ICE), 5);
        ALL[10] = u("Uçurum Dağları", b(Blocks.END_STONE), b(Blocks.END_STONE), b(Blocks.END_STONE), null, 0, 90, 45,
                0x10002A, 0x20104A, 0xC0A0FF, 0xE0B0FF, 0.012f, 0.5f, SPIKE, b(Blocks.PURPUR_BLOCK), 3);
        ALL[11] = u("Zehir Ovası", b(Blocks.GRASS), b(Blocks.DIRT), b(Blocks.STONE), b(Blocks.WATER), 62, 63, 6,
                0x0B3B0B, 0x1E5A1E, 0x3CFF1E, 0x7CFF00, 0.03f, 0f, SPIKE, b(Blocks.SLIME_BLOCK), 4);
        ALL[12] = u("Gölge Şehri", concrete(EnumDyeColor.GRAY), concrete(EnumDyeColor.GRAY), b(Blocks.STONE), null, 0, 64, 2,
                0x0A0A12, 0x1A1A24, 0x444455, 0x9999FF, 0.025f, 0.5f, PILLAR, b(Blocks.STONEBRICK), 9);
        ALL[13] = u("Kuzgun Dağları", b(Blocks.GRASS), b(Blocks.DIRT), b(Blocks.STONE), null, 0, 85, 40,
                0x151515, 0x303030, 0x203020, 0xCCCCFF, 0.02f, 0f, TREE, b(Blocks.LOG), 4);
        ALL[14] = u("Neon Kabus", black(), black(), b(Blocks.STONE), null, 0, 64, 6,
                0x000010, 0x100030, 0x00FFFF, 0xFF00FF, 0.015f, 0.5f, SPIKE, b(Blocks.SEA_LANTERN), 6);
        ALL[15] = u("Terk Edilmiş Köy", b(Blocks.GRASS), b(Blocks.DIRT), b(Blocks.STONE), null, 0, 65, 5,
                0x4A4A55, 0x6A6A70, 0x6A6A40, 0xFFFFFF, 0.03f, 0f, PILLAR, b(Blocks.PLANKS), 4);
        ALL[16] = u("Kristal Cehennem", b(Blocks.NETHERRACK), b(Blocks.NETHERRACK), b(Blocks.NETHERRACK), b(Blocks.LAVA), 40, 60, 16,
                0x600010, 0xA01030, 0xFF3060, 0xFFB0C0, 0.02f, 0f, SPIKE, b(Blocks.QUARTZ_BLOCK), 6);
        ALL[17] = u("Ruh Madeni", b(Blocks.SOUL_SAND), b(Blocks.SOUL_SAND), b(Blocks.NETHERRACK), null, 0, 64, 10,
                0x08141C, 0x0E2A38, 0x40E0D0, 0x40FFFF, 0.025f, 0.5f, PILLAR, b(Blocks.BONE_BLOCK), 4);
        ALL[18] = u("Sis Ormanı", b(Blocks.GRASS), b(Blocks.DIRT), b(Blocks.STONE), null, 0, 65, 8,
                0x7A8A7A, 0x8A9A8A, 0x405040, 0xFFFFFF, 0.06f, 0f, TREE, b(Blocks.LOG), 10);
        ALL[19] = u("Yeşil Işık Dünyası", b(Blocks.GRASS), b(Blocks.DIRT), b(Blocks.STONE), null, 0, 66, 10,
                0x002A10, 0x005A20, 0x00FF40, 0x00FF80, 0.02f, 0.5f, SPIKE, b(Blocks.EMERALD_BLOCK), 5);
        ALL[20] = u("Demir Çöl", b(Blocks.HARDENED_CLAY), b(Blocks.HARDENED_CLAY), b(Blocks.STONE), null, 0, 64, 12,
                0x6A5040, 0x8A6A50, 0xAA8855, 0xFFCC88, 0.015f, 0f, SPIKE, b(Blocks.IRON_BLOCK), 4);
        ALL[21] = u("Ölü Deniz", b(Blocks.GRAVEL), b(Blocks.GRAVEL), b(Blocks.STONE), b(Blocks.WATER), 72, 55, 10,
                0x20201A, 0x3A3A30, 0x5A5A3A, 0xCCCC99, 0.03f, 0f, SPIKE, b(Blocks.BONE_BLOCK), 3);
        ALL[22] = u("Sonsuz Koridor", concrete(EnumDyeColor.YELLOW), concrete(EnumDyeColor.YELLOW), b(Blocks.STONE), null, 0, 64, 0,
                0xD8CC80, 0xD8CC80, 0xD8CC80, 0xFFFFFF, 0.03f, 0f, PILLAR, b(Blocks.QUARTZ_BLOCK), 14);
        ALL[23] = u("Kırık Gökyüzü", b(Blocks.GRASS), b(Blocks.DIRT), b(Blocks.STONE), null, 0, 70, 20,
                0xFF4020, 0x401010, 0x806040, 0xFFFF00, 0.012f, 0.25f, SPIKE, b(Blocks.OBSIDIAN), 4);
        ALL[24] = u("Mavi Ateş Ovası", b(Blocks.GRASS), b(Blocks.DIRT), b(Blocks.STONE), null, 0, 64, 6,
                0x000830, 0x001060, 0x1030FF, 0x4080FF, 0.018f, 0.5f, SPIKE, b(Blocks.LAPIS_BLOCK), 5);
        ALL[25] = u("Örümcek Ormanı", b(Blocks.GRASS), b(Blocks.DIRT), b(Blocks.STONE), null, 0, 65, 8,
                0x0A0A0A, 0x1A1A1A, 0x302010, 0xFFFFFF, 0.035f, 0.5f, TREE, b(Blocks.LOG), 12);
        ALL[26] = u("Kül Dağları", b(Blocks.GRAVEL), b(Blocks.GRAVEL), b(Blocks.STONE), b(Blocks.LAVA), 50, 80, 35,
                0x303030, 0x505050, 0x707070, 0xFFAA55, 0.025f, 0f, SPIKE, b(Blocks.COAL_BLOCK), 4);
        ALL[27] = u("Lanetli Tapınak", b(Blocks.MOSSY_COBBLESTONE), b(Blocks.STONE), b(Blocks.STONE), null, 0, 64, 5,
                0x1A2A1A, 0x2A3A2A, 0x2F5F2F, 0x80FF80, 0.025f, 0f, PILLAR, b(Blocks.STONEBRICK), 6);
        ALL[28] = u("Beyaz Boşluk", concrete(EnumDyeColor.WHITE), concrete(EnumDyeColor.WHITE), b(Blocks.STONE), null, 0, 64, 1,
                0xFFFFFF, 0xFFFFFF, 0xFFFFFF, 0x000000, 0.05f, 0f, PILLAR, black(), 2);
        ALL[29] = u("Son Kapı", b(Blocks.END_STONE), b(Blocks.END_STONE), b(Blocks.END_STONE), null, 0, 64, 20,
                0x050010, 0x100020, 0xAA00FF, 0xFF00FF, 0.02f, 0.5f, PILLAR, b(Blocks.OBSIDIAN), 4);
    }

    /** Dimension ID -> evren indeksi (0-29), değilse -1 */
    public static int indexOfDim(int dim) {
        int i = dim - BASE_DIM;
        return (i >= 0 && i < COUNT) ? i : -1;
    }
}
