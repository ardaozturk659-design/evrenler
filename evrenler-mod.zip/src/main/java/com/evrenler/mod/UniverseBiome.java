package com.evrenler.mod;

import net.minecraft.util.math.BlockPos;
import net.minecraft.world.biome.Biome;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class UniverseBiome extends Biome {
    private final int idx;

    public UniverseBiome(int idx) {
        super(new Biome.BiomeProperties(Universes.ALL[idx].name)
                .setTemperature(0.5f).setRainfall(0.5f).setRainDisabled());
        this.idx = idx;
        this.topBlock = Universes.ALL[idx].top;
        this.fillerBlock = Universes.ALL[idx].fill;
    }

    @Override
    @SideOnly(Side.CLIENT)
    public int getGrassColorAtPos(BlockPos pos) {
        return ColorConfig.get(idx, ColorConfig.GRASS);
    }

    @Override
    @SideOnly(Side.CLIENT)
    public int getFoliageColorAtPos(BlockPos pos) {
        return ColorConfig.get(idx, ColorConfig.GRASS);
    }
}
