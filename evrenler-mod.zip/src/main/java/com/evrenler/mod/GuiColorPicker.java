package com.evrenler.mod;

import java.awt.Color;
import java.io.IOException;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.input.Keyboard;

/** Fotoğraftaki gibi renk seçici: hex kutusu, büyük renk karesi, sağda renk çubuğu. */
@SideOnly(Side.CLIENT)
public class GuiColorPicker extends GuiScreen {
    private static final String[] TITLES = {"Gökyüzünün Rengi", "Yıldırım Rengi", "Çimenin Rengi"};
    private static final int[] HUES = {0xFFFF0000, 0xFFFFFF00, 0xFF00FF00, 0xFF00FFFF, 0xFF0000FF, 0xFFFF00FF, 0xFFFF0000};
    private static final int W = 240, H = 160, BAR_W = 22, PW = 310, PH = 272;

    private final GuiScreen parent;
    private final int uni, type;
    private float hue, sat, val;
    private GuiTextField hex;
    private int drag = 0;
    private int px, py;

    public GuiColorPicker(GuiScreen parent, int uni, int type) {
        this.parent = parent;
        this.uni = uni;
        this.type = type;
        setFromRgb(ColorConfig.get(uni, type));
    }

    private int rgb() { return Color.HSBtoRGB(hue, sat, val) & 0xFFFFFF; }

    private void setFromRgb(int c) {
        float[] f = Color.RGBtoHSB((c >> 16) & 255, (c >> 8) & 255, c & 255, null);
        hue = f[0]; sat = f[1]; val = f[2];
    }

    private String hexString() { return String.format("#%06x", rgb()); }

    @Override
    public void initGui() {
        Keyboard.enableRepeatEvents(true);
        px = (width - PW) / 2;
        py = (height - PH) / 2;
        buttonList.clear();
        hex = new GuiTextField(10, fontRenderer, px + 50, py + 34, 110, 20);
        hex.setMaxStringLength(7);
        hex.setText(hexString());
        buttonList.add(new GuiButton(0, px + 12, py + PH - 30, 90, 20, "Uygula"));
        buttonList.add(new GuiButton(1, px + 110, py + PH - 30, 90, 20, "Sıfırla"));
        buttonList.add(new GuiButton(2, px + 208, py + PH - 30, 90, 20, "Geri"));
    }

    @Override
    public void onGuiClosed() { Keyboard.enableRepeatEvents(false); }

    @Override
    protected void actionPerformed(GuiButton b) throws IOException {
        if (b.id == 0) {
            ColorConfig.set(uni, type, rgb());
            ColorConfig.save();
            if (type == ColorConfig.GRASS) mc.renderGlobal.loadRenderers();
            mc.displayGuiScreen(parent);
        } else if (b.id == 1) {
            setFromRgb(ColorConfig.defaultOf(uni, type));
            hex.setText(hexString());
        } else {
            mc.displayGuiScreen(parent);
        }
    }

    private int sx() { return px + 12; }
    private int sy() { return py + 66; }
    private int bx() { return px + 12 + W + 12; }

    private void updateSV(int mx, int my) {
        sat = Math.max(0f, Math.min(1f, (mx - sx()) / (float) W));
        val = 1f - Math.max(0f, Math.min(1f, (my - sy()) / (float) H));
        hex.setText(hexString());
    }

    private void updateHue(int my) {
        hue = Math.max(0f, Math.min(0.999f, (my - sy()) / (float) H));
        hex.setText(hexString());
    }

    @Override
    protected void mouseClicked(int mx, int my, int btn) throws IOException {
        super.mouseClicked(mx, my, btn);
        hex.mouseClicked(mx, my, btn);
        if (btn == 0) {
            if (mx >= sx() && mx <= sx() + W && my >= sy() && my <= sy() + H) { drag = 1; updateSV(mx, my); }
            else if (mx >= bx() && mx <= bx() + BAR_W && my >= sy() && my <= sy() + H) { drag = 2; updateHue(my); }
        }
    }

    @Override
    protected void mouseClickMove(int mx, int my, int btn, long t) {
        if (drag == 1) updateSV(mx, my);
        else if (drag == 2) updateHue(my);
    }

    @Override
    protected void mouseReleased(int mx, int my, int state) {
        drag = 0;
        super.mouseReleased(mx, my, state);
    }

    @Override
    protected void keyTyped(char c, int code) throws IOException {
        if (code == Keyboard.KEY_ESCAPE) { mc.displayGuiScreen(parent); return; }
        if (hex.isFocused()) {
            hex.textboxKeyTyped(c, code);
            String t = hex.getText().trim();
            if (t.startsWith("#")) t = t.substring(1);
            if (t.length() == 6) {
                try { setFromRgb(Integer.parseInt(t, 16)); } catch (NumberFormatException ignored) {}
            }
        }
    }

    @Override
    public void updateScreen() { hex.updateCursorCounter(); }

    private void drawHGradient(int l, int t, int r, int b, int c1, int c2) {
        float a1 = (c1 >> 24 & 255) / 255f, r1 = (c1 >> 16 & 255) / 255f, g1 = (c1 >> 8 & 255) / 255f, b1 = (c1 & 255) / 255f;
        float a2 = (c2 >> 24 & 255) / 255f, r2 = (c2 >> 16 & 255) / 255f, g2 = (c2 >> 8 & 255) / 255f, b2 = (c2 & 255) / 255f;
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.disableAlpha();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.shadeModel(7425);
        Tessellator ts = Tessellator.getInstance();
        BufferBuilder bb = ts.getBuffer();
        bb.begin(7, DefaultVertexFormats.POSITION_COLOR);
        bb.pos(r, t, zLevel).color(r2, g2, b2, a2).endVertex();
        bb.pos(l, t, zLevel).color(r1, g1, b1, a1).endVertex();
        bb.pos(l, b, zLevel).color(r1, g1, b1, a1).endVertex();
        bb.pos(r, b, zLevel).color(r2, g2, b2, a2).endVertex();
        ts.draw();
        GlStateManager.shadeModel(7424);
        GlStateManager.disableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.enableTexture2D();
    }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        drawDefaultBackground();
        drawRect(px, py, px + PW, py + PH, 0xFF1F2433);
        drawString(fontRenderer, "RENK  -  " + TITLES[type], px + 12, py + 12, 0xAAAAAA);
        drawString(fontRenderer, "Evren " + (uni + 1) + ": " + Universes.ALL[uni].name, px + 12, py + 22, 0x666C80);

        // Önizleme kutusu
        drawRect(px + 12, py + 32, px + 44, py + 58, 0xFFFFFFFF);
        drawRect(px + 13, py + 33, px + 43, py + 57, 0xFF000000 | rgb());
        hex.drawTextBox();

        // Büyük renk karesi (beyaz -> saf renk, sonra alttan siyaha)
        int hueRgb = Color.HSBtoRGB(hue, 1f, 1f) | 0xFF000000;
        drawHGradient(sx(), sy(), sx() + W, sy() + H, 0xFFFFFFFF, hueRgb);
        drawGradientRect(sx(), sy(), sx() + W, sy() + H, 0x00000000, 0xFF000000);

        // Renk çubuğu
        for (int i = 0; i < 6; i++) {
            int y1 = sy() + i * H / 6, y2 = sy() + (i + 1) * H / 6;
            drawGradientRect(bx(), y1, bx() + BAR_W, y2, HUES[i], HUES[i + 1]);
        }

        // İşaretçiler
        int cx = sx() + (int) (sat * W), cy = sy() + (int) ((1f - val) * H);
        drawRect(cx - 4, cy - 4, cx + 5, cy + 5, 0xFFFFFFFF);
        drawRect(cx - 3, cy - 3, cx + 4, cy + 4, 0xFF000000 | rgb());
        int hy = sy() + (int) (hue * H);
        drawRect(bx() - 3, hy - 2, bx() + BAR_W + 3, hy + 3, 0xFFFFFFFF);

        // Alt satır: H / S / V
        drawString(fontRenderer, "H " + (int) (hue * 360) + "   S " + (int) (sat * 100) + "   V " + (int) (val * 100),
                px + 12, py + 66 + H + 8, 0xCCCCCC);

        super.drawScreen(mx, my, pt);
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
