package com.evrenler.mod;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

import javax.annotation.Nullable;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkPrimer;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraft.world.gen.NoiseGeneratorPerlin;

public class UniverseChunkGenerator implements IChunkGenerator {
    private final World world;
    private final int idx;
    private final Universes.UniverseData u;
    private final NoiseGeneratorPerlin noise, noise2;
    private final Biome biome;

    public UniverseChunkGenerator(World world, int idx) {
        this.world = world;
        this.idx = idx;
        this.u = Universes.ALL[idx];
        this.biome = ModBiomes.BIOMES[idx];
        Random r = new Random(world.getSeed() + idx * 7919L);
        this.noise = new NoiseGeneratorPerlin(r, 4);
        this.noise2 = new NoiseGeneratorPerlin(r, 2);
    }

    private int height(int wx, int wz) {
        double n = noise.getValue(wx * 0.006, wz * 0.006) * 0.6 + noise2.getValue(wx * 0.05, wz * 0.05) * 0.15;
        double factor = 1.0;
        if (u.castle) {
            int d = Math.max(Math.abs(wx), Math.abs(wz));
            factor = Math.max(0.0, Math.min(1.0, (d - 110) / 90.0)); // şato çevresi düz
        }
        int h = (int) Math.round(u.base + n * u.amp * factor);
        return Math.max(2, Math.min(240, h));
    }

    @Override
    public Chunk generateChunk(int cx, int cz) {
        ChunkPrimer p = new ChunkPrimer();
        IBlockState bedrock = Blocks.BEDROCK.getDefaultState();
        boolean castle = u.castle && CastleGenerator.overlapsChunk(cx, cz);

        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                int wx = cx * 16 + x, wz = cz * 16 + z;
                int h = height(wx, wz);
                for (int y = 0; y <= h; y++) {
                    IBlockState s;
                    if (y == 0) s = bedrock;
                    else if (y == h) s = u.top;
                    else if (y >= h - 3) s = u.fill;
                    else s = u.stone;
                    p.setBlockState(x, y, z, s);
                }
                if (u.liquid != null) {
                    for (int y = h + 1; y <= u.sea; y++) p.setBlockState(x, y, z, u.liquid);
                }
                if (castle) {
                    for (int y = 64; y <= CastleGenerator.MAX_Y; y++) {
                        IBlockState c = CastleGenerator.get(wx, y, wz);
                        if (c != null) p.setBlockState(x, y, z, c);
                    }
                }
            }
        }

        Chunk chunk = new Chunk(world, p, cx, cz);
        byte[] ba = chunk.getBiomeArray();
        Arrays.fill(ba, (byte) Biome.getIdForBiome(biome));
        chunk.generateSkylightMap();
        return chunk;
    }

    @Override
    public void populate(int cx, int cz) {
        if (u.decorKind == Universes.NONE) return;
        Random r = new Random(world.getSeed() * 31L + cx * 341873128712L + cz * 132897987541L);
        for (int i = 0; i < u.decorCount; i++) {
            int x = cx * 16 + 8 + r.nextInt(16);
            int z = cz * 16 + 8 + r.nextInt(16);
            if (u.castle && Math.abs(x) < 95 && Math.abs(z) < 95) continue;
            BlockPos top = world.getHeight(new BlockPos(x, 0, z));
            if (top.getY() <= 2) continue;
            if (world.getBlockState(top.down()).getMaterial().isLiquid()) continue;
            switch (u.decorKind) {
                case Universes.SPIKE: spike(top, r); break;
                case Universes.TREE: tree(top, r); break;
                case Universes.PILLAR: pillar(top, r); break;
                default: break;
            }
        }
    }

    private void put(BlockPos pos) { world.setBlockState(pos, u.decor, 2); }

    private void spike(BlockPos base, Random r) {
        int h = 5 + r.nextInt(14);
        for (int dy = 0; dy < h; dy++) {
            int rad = dy < h / 3 ? 1 : 0;
            for (int dx = -rad; dx <= rad; dx++)
                for (int dz = -rad; dz <= rad; dz++)
                    if (Math.abs(dx) + Math.abs(dz) <= rad) put(base.add(dx, dy, dz));
        }
    }

    private void tree(BlockPos base, Random r) {
        int h = 5 + r.nextInt(5);
        for (int dy = 0; dy < h; dy++) put(base.up(dy));
        for (int b = 0; b < 3; b++) {
            int by = 2 + r.nextInt(Math.max(1, h - 2));
            int dirX = r.nextInt(3) - 1, dirZ = r.nextInt(3) - 1;
            if (dirX == 0 && dirZ == 0) dirX = 1;
            int len = 2 + r.nextInt(3);
            for (int k = 1; k <= len; k++) put(base.add(dirX * k, by + (k / 2), dirZ * k));
        }
    }

    private void pillar(BlockPos base, Random r) {
        int h = 4 + r.nextInt(9);
        for (int dy = 0; dy < h; dy++) {
            if (dy > 3 && r.nextInt(7) == 0) continue; // kırık görünüm
            for (int dx = 0; dx < 2; dx++)
                for (int dz = 0; dz < 2; dz++) put(base.add(dx, dy, dz));
        }
    }

    @Override
    public boolean generateStructures(Chunk chunkIn, int x, int z) { return false; }

    @Override
    public List<Biome.SpawnListEntry> getPossibleCreatures(EnumCreatureType type, BlockPos pos) {
        return biome.getSpawnableList(type);
    }

    @Nullable
    @Override
    public BlockPos getNearestStructurePos(World w, String name, BlockPos pos, boolean findUnexplored) { return null; }

    @Override
    public void recreateStructures(Chunk chunkIn, int x, int z) {}

    @Override
    public boolean isInsideStructure(World w, String name, BlockPos pos) { return false; }
}
