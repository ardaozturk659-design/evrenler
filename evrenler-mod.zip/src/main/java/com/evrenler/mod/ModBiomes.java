package com.evrenler.mod;

import net.minecraft.world.biome.Biome;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = EvrenMod.MODID)
public class ModBiomes {
    public static final Biome[] BIOMES = new Biome[Universes.COUNT];

    @SubscribeEvent
    public static void register(RegistryEvent.Register<Biome> e) {
        for (int i = 0; i < Universes.COUNT; i++) {
            BIOMES[i] = new UniverseBiome(i);
            BIOMES[i].setRegistryName(EvrenMod.MODID, "evren_" + (i + 1));
            e.getRegistry().register(BIOMES[i]);
        }
    }
}
