package com.evrenler.mod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraftforge.client.IRenderHandler;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/** Düz renkli gökyüzü: ufukta sis rengi, yukarıda ayarlanan gökyüzü rengi. */
@SideOnly(Side.CLIENT)
public class SkyRenderer extends IRenderHandler {
    public static final SkyRenderer INSTANCE = new SkyRenderer();

    private static void v(BufferBuilder b, float x, float y, float z, int c) {
        b.pos(x, y, z).color(((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f, 1f).endVertex();
    }

    @Override
    public void render(float partialTicks, WorldClient world, Minecraft mc) {
        int idx = Universes.indexOfDim(world.provider.getDimension());
        if (idx < 0) return;
        int sky = ColorConfig.get(idx, ColorConfig.SKY);
        int fog = Universes.ALL[idx].fog;

        GlStateManager.disableTexture2D();
        GlStateManager.disableFog();
        GlStateManager.disableAlpha();
        GlStateManager.disableCull();
        GlStateManager.depthMask(false);
        RenderHelper.disableStandardItemLighting();

        Tessellator t = Tessellator.getInstance();
        BufferBuilder b = t.getBuffer();
        b.begin(7, DefaultVertexFormats.POSITION_COLOR);
        float d = 120f;
        float[][] c = {{-d, -d}, {d, -d}, {d, d}, {-d, d}};
        for (int i = 0; i < 4; i++) {
            float x1 = c[i][0], z1 = c[i][1], x2 = c[(i + 1) % 4][0], z2 = c[(i + 1) % 4][1];
            v(b, x1, -d, z1, fog); v(b, x2, -d, z2, fog); v(b, x2, 0, z2, fog); v(b, x1, 0, z1, fog);
            v(b, x1, 0, z1, fog); v(b, x2, 0, z2, fog); v(b, x2, d, z2, sky); v(b, x1, d, z1, sky);
        }
        v(b, -d, d, -d, sky); v(b, -d, d, d, sky); v(b, d, d, d, sky); v(b, d, d, -d, sky);
        v(b, -d, -d, -d, fog); v(b, d, -d, -d, fog); v(b, d, -d, d, fog); v(b, -d, -d, d, fog);
        t.draw();

        GlStateManager.depthMask(true);
        GlStateManager.enableCull();
        GlStateManager.enableTexture2D();
        GlStateManager.enableAlpha();
        GlStateManager.enableFog();
    }
}
