package com.evrenler.mod;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

/** Her evren için gökyüzü / yıldırım / çimen rengini tutar ve dosyaya kaydeder. */
public class ColorConfig {
    public static final int SKY = 0, LIGHTNING = 1, GRASS = 2;
    private static final String[] NAMES = {"gokyuzu", "yildirim", "cimen"};
    private static final int[][] VAL = new int[Universes.COUNT][3];
    private static File file;

    public static int defaultOf(int u, int t) {
        Universes.UniverseData d = Universes.ALL[u];
        return t == SKY ? d.sky : (t == LIGHTNING ? d.lightning : d.grass);
    }

    private static String key(int u, int t) { return "evren" + (u + 1) + "." + NAMES[t]; }

    public static void init(File dir) {
        file = new File(dir, "evrenler_renkler.properties");
        for (int u = 0; u < Universes.COUNT; u++)
            for (int t = 0; t < 3; t++) VAL[u][t] = defaultOf(u, t);
        if (file.exists()) {
            Properties p = new Properties();
            try (FileInputStream in = new FileInputStream(file)) {
                p.load(in);
            } catch (IOException ignored) {}
            for (int u = 0; u < Universes.COUNT; u++)
                for (int t = 0; t < 3; t++) {
                    String s = p.getProperty(key(u, t));
                    if (s != null) {
                        try { VAL[u][t] = Integer.parseInt(s.trim(), 16) & 0xFFFFFF; } catch (NumberFormatException ignored) {}
                    }
                }
        }
    }

    public static int get(int u, int t) {
        if (u < 0 || u >= Universes.COUNT) return 0xFFFFFF;
        return VAL[u][t];
    }

    public static void set(int u, int t, int rgb) {
        if (u >= 0 && u < Universes.COUNT) VAL[u][t] = rgb & 0xFFFFFF;
    }

    public static void save() {
        if (file == null) return;
        Properties p = new Properties();
        for (int u = 0; u < Universes.COUNT; u++)
            for (int t = 0; t < 3; t++) p.setProperty(key(u, t), String.format("%06x", VAL[u][t]));
        try (FileOutputStream out = new FileOutputStream(file)) {
            p.store(out, "Evrenler renk ayarlari");
        } catch (IOException ignored) {}
    }
}
