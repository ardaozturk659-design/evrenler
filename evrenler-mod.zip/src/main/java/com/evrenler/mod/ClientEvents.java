package com.evrenler.mod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.input.Keyboard;

@SideOnly(Side.CLIENT)
public class ClientEvents {
    public static final KeyBinding KEY = new KeyBinding("Renk Ayarları", Keyboard.KEY_B, "Evrenler");

    /** Şu an bulunulan evrenin indeksi, evrende değilse -1 */
    public static int current() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.world == null) return -1;
        return Universes.indexOfDim(mc.world.provider.getDimension());
    }

    @SubscribeEvent
    public void onKey(InputEvent.KeyInputEvent e) {
        if (KEY.isPressed()) Minecraft.getMinecraft().displayGuiScreen(new GuiColorMenu());
    }

    @SubscribeEvent
    public void fogColor(EntityViewRenderEvent.FogColors e) {
        int i = current();
        if (i < 0 || e.getState().getMaterial().isLiquid()) return;
        int c = Universes.ALL[i].fog;
        e.setRed(((c >> 16) & 255) / 255f);
        e.setGreen(((c >> 8) & 255) / 255f);
        e.setBlue((c & 255) / 255f);
    }

    @SubscribeEvent
    public void fogDensity(EntityViewRenderEvent.FogDensity e) {
        int i = current();
        if (i < 0 || e.getState().getMaterial().isLiquid()) return;
        GlStateManager.setFog(GlStateManager.FogMode.EXP);
        e.setDensity(Universes.ALL[i].density);
        e.setCanceled(true);
    }
}
