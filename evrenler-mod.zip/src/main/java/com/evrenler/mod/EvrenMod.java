package com.evrenler.mod;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;

@Mod(modid = EvrenMod.MODID, name = "Evrenler", version = "1.0", acceptedMinecraftVersions = "[1.12.2]")
public class EvrenMod {
    public static final String MODID = "evrenler";

    @SidedProxy(clientSide = "com.evrenler.mod.ClientProxy", serverSide = "com.evrenler.mod.CommonProxy")
    public static CommonProxy proxy;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent e) {
        ColorConfig.init(e.getModConfigurationDirectory());
        ModDimensions.register();
        MinecraftForge.EVENT_BUS.register(new CommonEvents());
        proxy.preInit(e);
    }

    @Mod.EventHandler
    public void serverStarting(FMLServerStartingEvent e) {
        e.registerServerCommand(new CommandEvren());
    }
}
