package com.evrenler.mod;

import net.minecraft.world.DimensionType;
import net.minecraftforge.common.DimensionManager;

public class ModDimensions {
    public static final DimensionType[] TYPES = new DimensionType[Universes.COUNT];

    public static void register() {
        for (int i = 0; i < Universes.COUNT; i++) {
            int id = Universes.BASE_DIM + i;
            TYPES[i] = DimensionType.register("Evren " + (i + 1), "_evren_" + (i + 1), id, UniverseProvider.class, false);
            DimensionManager.registerDimension(id, TYPES[i]);
        }
    }
}
